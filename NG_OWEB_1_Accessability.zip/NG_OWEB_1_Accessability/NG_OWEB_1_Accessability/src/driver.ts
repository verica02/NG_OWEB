        
export interface driver{
    id: Number;
    name: string;
    iconUrl: string;
    team: String;
    category: String;
    points: Number;

}
     