export interface driver{
    id: number;
    name: string;
    iconUrl: string;
    team: string;
    category: string;
    points: number;
}